﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text;

namespace SamzyAuth_Example
{
    class Program
    {
        static readonly SamzyAuth api = new SamzyAuth("Application name", "Application Key", "Application Encryption Key", "Application Version");
        /* Application properties
             * Console.WriteLine(App.Freemode); // bool
             * Console.WriteLine(App.updaterLink); // string
             * Console.WriteLine(App.Version); // string
             * Console.WriteLine(App.devMode); // bool
             * Console.WriteLine(App.enableUpdater); // bool
             * Console.WriteLine(App.hashcheck); // bool
             * Console.WriteLine(App.hashProgram); // string
             * Console.WriteLine(App.HWIDLock); // bool
             */
        static void Main()
        {
            api.Connect();            
            Console.Title = "SamzyAuth | Console Example";
            Console.WriteLine(Environment.NewLine + " SamzyAuth | Console Example");
            Console.WriteLine(" ------------------------------------------------");
            Console.WriteLine(" 1. Login");
            Console.WriteLine(" 2. Register");
            Console.WriteLine(" 3. All For One");
            Console.WriteLine(" 4. Extend subscription");
            Console.WriteLine(" ------------------------------------------------");
            Console.Write(Environment.NewLine + " Option: ");
            Menu(Console.ReadLine());            
        }
        public static void Menu(string option)
        {
            if (option == "1") 
            {
                Console.Write(Environment.NewLine + " Username: ");
                string username = Console.ReadLine();
                Console.Write(" Password: ");
                string password = Console.ReadLine();

                if (api.Login(username, password))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CustomerMenu();
                }
            }
            else if (option == "2")
            {
                Console.Write(Environment.NewLine + " Username: ");
                string username = Console.ReadLine();
                Console.Write(" Password: ");
                string password = Console.ReadLine();
                Console.Write(" License: ");
                string license = Console.ReadLine();

                if (api.Register(username, password, license))
                {
                    MessageBox.Show("Successfully registered!, Please log in", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Application.Restart();
                    Process.GetCurrentProcess().Kill();
                }
            }
            else if (option == "3")
            {
                Console.Write(Environment.NewLine + " License: ");
                if (api.licenseLogin(Console.ReadLine()))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CustomerMenu();
                }
            }
            else if (option == "4")
            {
                Console.Write(Environment.NewLine + " Username: ");
                string username = Console.ReadLine();
                Console.Write(" Password: ");
                string password = Console.ReadLine();
                Console.Write(" License: ");
                string license = Console.ReadLine();
                if (api.ExtendTime(username, password, license))
                {
                    MessageBox.Show("Your user's time has been extended successfully!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Environment.Exit(0);
                }
            }
            else
            {
                MessageBox.Show("Invalid option", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
            Console.ReadLine();
        }
        public static void CustomerMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(Environment.NewLine + " SamzyAuth | Console Example");
                Console.WriteLine(" ------------------------------------------------");
                Console.WriteLine(" Username: " + Info.Username);
                Console.WriteLine(" License Used: " + Info.License);
                Console.WriteLine(" HWID: " + Info.HWID);
                Console.WriteLine(" IP: " + Info.IP);
                Console.WriteLine(" Expiry: " + Info.Expires);
                Console.WriteLine(" Rank: " + Info.Level); // You can control the permissions between accounts by assigning a different level
                Console.WriteLine(" ------------------------------------------------");
                Console.WriteLine(" 1. Capture variable"); // (string) = api.captureVariable("variable name"); return the value
                Console.WriteLine(" ------------------------------------------------");
                Console.Write(Environment.NewLine + " Option: ");
                int opt = int.Parse(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.Write(Environment.NewLine + " Secure variable code: ");
                        string varCode = Console.ReadLine();
                        MessageBox.Show($"Value: {api.captureVariable(varCode)}", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }
            }
        }
    }
}
